package tu.paquete;

import org.mindrot.jbcrypt.BCrypt;

public class PruebaBCrypt {
    public static void main(String[] args) {
        String password = "1234";
        String hash = BCrypt.hashpw(password, BCrypt.gensalt());
        System.out.println("Hash: " + hash);

        // Verificar contraseña
        boolean valido = BCrypt.checkpw(password, hash);
        System.out.println("¿Válido? " + valido);
    }
}