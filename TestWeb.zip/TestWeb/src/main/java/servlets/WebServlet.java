/**
 * 
 */
package servlets;

import java.lang.annotation.Documented;

@Documented
/**
 * 
 */
public @interface WebServlet {

	String value();

}
