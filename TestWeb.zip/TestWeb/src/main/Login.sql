-- SQLBook: Code
CREATE SCHEMA IF NOT EXISTS testweb CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci ;
USE testweb;

CREATE TABLE IF NOT EXISTS usuarios(
    ID INT AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL, -- A futuro pondré más restriones.
    password CHAR(6) NOT NULL,
    PRIMARY KEY(ID),
    CONSTRAINT password CHECK (password REGEXP '^[0-9]{6}$')
);